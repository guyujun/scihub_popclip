# SCI-HUB DOI

A PopClip Extension to get the result from sci-hub.io.

## Icon

![icon](https://raw.githubusercontent.com/tsaiid/PopClip-Extensions/master/SciHubDoi.popclipext/sci-hub-doi.png)

Modified from:

1. Document, file, pdf icon and key icon by [Yannick Lung](https://www.iconfinder.com/yanlu).
